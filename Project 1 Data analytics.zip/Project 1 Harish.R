library(randomForest)
library(caret)
library(rpart)
library(e1071)
library(ggplot2)
data <- read.csv("C:/Users/Harish/Downloads/archive (4)/BRCA.csv")
any_missing <- anyNA(data[, 4:7])
# If there are missing values, handle them appropriately
if (any_missing) {
  # Handle missing values 
  data <- na.omit(data)
}
data$Patient_Status <- factor(data$Patient_Status, levels = c("Alive", "Dead"))

# Implement Random Forest
set.seed(123)
trainIndex <- createDataPartition(data$Patient_Status, p = .7, 
                                  list = FALSE, 
                                  times = 1)
data_train <- data[trainIndex, ]
data_test <- data[-trainIndex, ]
data_train <- na.omit(data_train)

# Train the Random Forest model
rf_model <- randomForest(Patient_Status ~ Protein1 + Protein2 + Protein3 + Protein4, 
                         data = data_train)

# Implement Decision Tree 
dt_model <- rpart(Patient_Status ~ Protein1 + Protein2 + Protein3 + Protein4, 
                  data = data_train, 
                  method = "class")

# Confusion Matrix for Random Forest
rf_predictions <- predict(rf_model, newdata = data_test)
confusionMatrix(rf_predictions, data_test$Patient_Status)

# Confusion Matrix for Decision Tree 
dt_predictions <- predict(dt_model, newdata = data_test, type = "class")
confusionMatrix(dt_predictions, data_test$Patient_Status)

# Implement Principal Component Analysis (PCA)
pca_model <- prcomp(data[, 4:7], scale. = TRUE)

# Implement Decision Tree
dt_model <- rpart(Patient_Status ~ Protein1 + Protein2 + Protein3 + Protein4, 
                  data = data_train, 
                  method = "class")
library(rpart)
library(rpart.plot)
data <- iris
target <- "Species"
train_data <- data
# Create the CART model
cart_model <- rpart(formula = as.formula(paste(target, "~ .")), data = train_data, method = "class")
# Plot the decision tree
prp(cart_model, extra = 1, main = "Decision Tree (CART)")
# Plotting
plot(pca_model$x[,1:2], col=data$Patient_Status, pch=19,
     xlab="Principal Component 1", ylab="Principal Component 2",
     main="PCA of Breast Cancer Data")
legend("topright", legend=levels(data$Patient_Status), 
       col=1:length(levels(data$Patient_Status)), pch=19)


